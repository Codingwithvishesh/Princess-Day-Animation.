
import turtle as t
import math as m
import random as r
import time

# ---------------- SCREEN SETUP ----------------

s = t.Screen()
s.setup(600, 600)
s.bgcolor("black")
s.title("Happy Princess Day ❤️")
s.tracer(0)

p = t.Turtle()
p.hideturtle()
p.penup()
p.speed(0)

N = 700
STEPS = 70

# ---------------- HEART COLORS ----------------

RED = ["#ff1744", "#ff003c", "#ff3366", "#ff6688"]

# ---------------- PARTICLE FONT ----------------

FONT = {
    "A": ["01110","10001","10001","11111","10001","10001","10001"],
    "C": ["01111","10000","10000","10000","10000","10000","01111"],
    "D": ["11110","10001","10001","10001","10001","10001","11110"],
    "E": ["11111","10000","10000","11110","10000","10000","11111"],
    "H": ["10001","10001","10001","11111","10001","10001","10001"],
    "I": ["11111","00100","00100","00100","00100","00100","11111"],
    "N": ["10001","11001","11001","10101","10011","10011","10001"],
    "P": ["11110","10001","10001","11110","10000","10000","10000"],
    "R": ["11110","10001","10001","11110","10100","10010","10001"],
    "S": ["01111","10000","10000","01110","00001","00001","11110"],
    "Y": ["10001","10001","01010","00100","00100","00100","00100"]
}

# ---------------- HEART SHAPE ----------------

def heart_point(i):

    a = 2 * m.pi * i / N

    x = 16 * m.sin(a)**3 * 11

    y = (
        13 * m.cos(a)
        - 5 * m.cos(2*a)
        - 2 * m.cos(3*a)
        - m.cos(4*a)
    ) * 11

    return (
        x + r.uniform(-2, 2),
        y + r.uniform(-2, 2)
    )


heart_targets = [heart_point(i) for i in range(N)]

random_starts = [
    (r.randint(-280, 280), r.randint(-280, 280))
    for _ in range(N)
]

heart_colors = [r.choice(RED) for _ in range(N)]


# ---------------- TEXT PARTICLES ----------------

def create_text_targets():

    messages = ["HAPPY", "PRINCESS", "DAY"]

    scale = 7
    char_step = 6 * scale
    line_gap = 65

    targets = []

    for line_index, message in enumerate(messages):

        total_width = len(message) * char_step - scale

        start_x = -total_width / 2
        top_y = 110 - line_index * line_gap

        for char_index, char in enumerate(message):

            pattern = FONT[char]

            for row in range(7):
                for col in range(5):

                    if pattern[row][col] == "1":

                        x = (
                            start_x
                            + char_index * char_step
                            + col * scale
                        )

                        y = top_y - row * scale

                        targets.append((x, y))

    # Distribute exactly N particles across the letters

    final_targets = []

    for i in range(N):

        x, y = targets[i % len(targets)]

        final_targets.append((
            x + r.uniform(-1.5, 1.5),
            y + r.uniform(-1.5, 1.5)
        ))

    return final_targets


# ---------------- ANIMATION ENGINE ----------------

def animate(starts, ends, colors):

    for frame in range(STEPS + 1):

        p.clear()

        progress = frame / STEPS

        eased = 0.5 - 0.5 * m.cos(progress * m.pi)

        for i in range(N):

            sx, sy = starts[i]
            ex, ey = ends[i]

            x = sx + (ex - sx) * eased
            y = sy + (ey - sy) * eased

            p.goto(x, y)
            p.dot(4, colors[i])

        s.update()
        time.sleep(0.02)


# ---------------- SCENE 1: RED HEART ----------------

animate(
    random_starts,
    heart_targets,
    heart_colors
)

time.sleep(1.5)


# ---------------- SCENE 2: PRINCESS DAY TEXT ----------------

text_targets = create_text_targets()

text_colors = [
    r.choice([
        "#ff4fa3",
        "#ff80bf",
        "#ffd166",
        "#ffffff"
    ])
    for _ in range(N)
]

animate(
    heart_targets,
    text_targets,
    text_colors
)


# ---------------- FINAL DISPLAY ----------------


